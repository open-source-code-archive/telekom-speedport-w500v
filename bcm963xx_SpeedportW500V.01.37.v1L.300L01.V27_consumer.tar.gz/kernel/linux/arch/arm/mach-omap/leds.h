extern void innovator_leds_event(led_event_t evt);
extern void perseus2_leds_event(led_event_t evt);



extern void s3c2410_map_io(struct map_desc *, int count);

extern void s3c2410_init_irq(void);

extern void s3c2410_init_time(void);


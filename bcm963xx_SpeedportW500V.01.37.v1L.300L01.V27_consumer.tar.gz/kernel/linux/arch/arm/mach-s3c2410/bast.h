
extern void bast_init_irq(void);
